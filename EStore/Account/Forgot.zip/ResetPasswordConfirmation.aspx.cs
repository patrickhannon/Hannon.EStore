﻿using System.Web.UI;

namespace EStore.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}